// Desc: This program is to allow a user to enter information and generate a receipt for the St. John's Marina & Yacht Club.
// Author: Keira Hancock
// Dates: Nov 15 - 29 2024



// Define program constants.

const EVEN_NUM = 80.00 // Dollars.
const ODD_NUM = 120.00 // Dollars.
const ALT_MEMBER = 5.00 // Dollars per alternate member.

const SITE_CLEAN = 50.00 // Dollars per month.
const VIDEO_SURV = 35.00 // Dollars per month.

const HST_RATE = 0.15 // Percent.

const STANDARD_DUES = 75.00 // Dollars per month.
const EXECUTIVE_DUES = 150.00 // Dollars per month.

const PROCESSING_FEE = 59.99 // Dollars per month.
const CANCELLATION_FEE = 0.6 // Percent.



// Define format options for printing.

const cur2Format = new Intl.NumberFormat("en-CA", {
    style: "currency",
    currency: "CAD",
    minimumFractionDigits: "2",
    maximumFractionDigits: "2",
});

const per2Format = new Intl.NumberFormat("en-CA", {
    style: "percent",
    minimumFractionDigits: "2",
    maximumFractionDigits: "2",
});

const com2Format = new Intl.NumberFormat("en-CA", {
    style: "decimal",
    minimumFractionDigits: "2",
    maximumFractionDigits: "2",
});



// Get user input.

let CurDate = prompt("Enter the Current Date (YYYY-MM-DD): ");
let SiteNum = prompt("Enter the Site Number (1-100): ");
SiteNum = parseInt(SiteNum);

let MemName = prompt("Enter the Member Name: ");
let MemAddress = prompt("Enter the Member Street Address: ");
let MemCity = prompt("Enter the Member City: ");
let MemProvince = prompt("Enter the Member Province (LL): ").toUpperCase();
let MemPostalCode = prompt("Enter the Member Postal Code (LOLOLO):").toUpperCase();
let PhoneNum = prompt("Enter the Member Phone Number (0000000000):");
let CellNum = prompt("Enter the Member Cell Number (0000000000):");

let MemType = prompt("Enter Membership Type (S for Standard, E for Executive): ").toUpperCase();
let NumAltMem = prompt("Enter the Number of Alternate Members: ");
NumAltMem = parseInt(NumAltMem);

let WeeklyClean = prompt("Add the Weekly Site Cleaning Option (Y/N): ").toUpperCase();
let VideoSurv = prompt("Add the Video Surveillance Option (Y/N): ").toUpperCase();



// Generate calculated results.

// Processing option for site cost based on even and odd numbers.
// The modulus operator (%) returns the remainder.
RemSite = SiteNum % 2;
if (RemSite == 0) {
    EvenOdd = EVEN_NUM;
} else {
    EvenOdd = ODD_NUM;
}

AltMemCost = ALT_MEMBER * NumAltMem;

SiteCharge = EvenOdd + AltMemCost;

// Processing option for weekly site cleaning.
if (WeeklyClean == "Y") {
    CleanCost = SITE_CLEAN;
} else {
    CleanCost = 0.00;
}

// Processing option for video surveillance.
if (VideoSurv == "Y") {
    VideoSurvCost = VIDEO_SURV;
} else {
    VideoSurvCost = 0.00;
}

ExtraCharge = CleanCost + VideoSurvCost;

Subtotal = SiteCharge + ExtraCharge;

HST = Subtotal * HST_RATE;

TotalMonthlyCharge = Subtotal * HST;

// Processing option for monthly dues based on standard or executive dues.
if (MemType == "E") {
    MonthlyDues = EXECUTIVE_DUES;
} else {
    MonthlyDues = STANDARD_DUES;
}

TotalMonthlyFees = TotalMonthlyCharge + MonthlyDues;

TotalYearlyFees = TotalMonthlyFees * 12;

MonthlyPayment = (TotalYearlyFees + PROCESSING_FEE) / 12;

YearlySiteCharge = Subtotal * 12;

CancellationFee = YearlySiteCharge * CANCELLATION_FEE;



// Generate receipt for the receptionist and member.

document.write("<table class = 'resultstable'>");

document.write("<tr>");
document.write("<td class = 'centertext' colspan='2'><br />St. John's Marina & Yacht Club<br />Yearly Member Receipt<br /><br /></td>");
document.write("</tr>");

document.write("<tr>");
document.write("<td colspan='2'><br />Client Name and Address:<br /><br /></td>");
document.write("</tr>");

document.write("<tr>");
document.write("<td colspan='2'>" + MemName + "<br />" + MemAddress + "<br />" + MemCity + ", " + MemProvince + " " + MemPostalCode + "<br />" + "<br />" + "Phone: " + PhoneNum + " (H)" + "<br />" + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + CellNum + " (C)" + "</td>");
document.write("</tr>");

// Processing for member type option.
if (MemType == "E") {
    TypeName = "Executive";
} else {
    TypeName = "Standard";
}

document.write("<tr>");
document.write("<td class = 'lefttext'>" + "Site #: " + SiteNum + "</td>");
document.write("<td class = 'righttext'>" + "Member Type: " + TypeName + "</td");
document.write("</tr>");

// Processing Y/N option for both weekly cleaning and video surveillance.
if (WeeklyClean == "Y") {
    CleanChoice = "Yes";
} else {
    CleanChoice = "No";
}
if (VideoSurv == "Y") {
    VideoChoice = "Yes";
} else {
    VideoChoice = "No";
}

document.write("<tr>");
document.write("<td class = 'lefttext'>Alternate members:  <br />Weekly site cleaning: <br />Video surveillance: </td>");
document.write("<td class = 'righttext'>" + NumAltMem + "<br />" + CleanChoice + "<br />" + VideoChoice + "</td>");
document.write("</tr>");

document.write("<tr>");
document.write("<td class = 'lefttext'>Site charges: <br />Extra charges: </td>");
document.write("<td class = 'righttext'>" + cur2Format.format(SiteCharge) + "<br />" + cur2Format.format(ExtraCharge) + "</td>");
document.write("</tr>");

document.write("<tr>");
document.write("<td class = 'lefttext'>Subtotal: <br />Sales tax (HST): </td>");
document.write("<td class = 'righttext'>" + cur2Format.format(Subtotal) + "<br />" + cur2Format.format(HST) + "</td>");
document.write("</tr>");

document.write("<tr>");
document.write("<td class = 'lefttext'>Total monthly charges: <br />Monthly dues: </td>");
document.write("<td class = 'righttext'>" + cur2Format.format(TotalMonthlyCharge) + "<br />" + cur2Format.format(MonthlyDues) + "</td>");
document.write("</tr>");

document.write("<tr>");
document.write("<td class = 'lefttext'>Total monthly fees: <br />Total yearly fees: </td>");
document.write("<td class = 'righttext'>" + cur2Format.format(TotalMonthlyFees) + "<br />" + cur2Format.format(TotalYearlyFees) + "</td>");
document.write("</tr>");

document.write("<tr>");
document.write("<td class = 'lefttext'>Monthly payment: <br /></td>");
document.write("<td class = 'righttext'>" + cur2Format.format(MonthlyPayment) + "<br />" + "</td>");
document.write("</tr>");

document.write("<tr>");
document.write("<td class = 'lefttext'>Issued: <br /><br />HST Reg No.: <br /><br />Cancellation fee: </td>");
document.write("<td class = 'righttext'>" + CurDate + "<br />" + "<br />" + "549-33-5849-47" + "<br />" + "<br />" + cur2Format.format(CancellationFee) + "</td>");
document.write("</tr>");

document.write("</table>");